
package com.cryptopulse.model

data class Trade(
    val coin: String,
    val amount: Double,
    val buyPrice: Double,
    val currentPrice: Double
) {
    fun invested() = amount * buyPrice
    fun value() = amount * currentPrice
    fun pnl() = value() - invested()
    fun pnlPercent() = if (invested() == 0.0) 0.0 else (pnl() / invested()) * 100
}
