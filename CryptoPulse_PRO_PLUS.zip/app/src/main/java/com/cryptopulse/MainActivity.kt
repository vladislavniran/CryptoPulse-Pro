
package com.cryptopulse

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cryptopulse.model.Trade

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CryptoPulseApp()
        }
    }
}

@Composable
fun CryptoPulseApp() {

    var btc by remember { mutableStateOf(35000.0) }
    var eth by remember { mutableStateOf(2200.0) }

    val trades = listOf(
        Trade("BTC", 0.5, 30000.0, btc),
        Trade("ETH", 2.0, 1800.0, eth)
    )

    val totalPnL = trades.sumOf { it.pnl() }
    val totalValue = trades.sumOf { it.value() }

    MaterialTheme {

        Column(Modifier.fillMaxSize().padding(16.dp)) {

            Text("Крипто Пульс 🚀", style = MaterialTheme.typography.headlineMedium)

            Spacer(Modifier.height(12.dp))

            Card {
                Column(Modifier.padding(16.dp)) {
                    Text("💰 Портфель: $${totalValue}")
                    Text("📈 PnL: $${totalPnL}")
                }
            }

            Spacer(Modifier.height(12.dp))

            LazyColumn {
                items(trades) { t ->
                    Card(Modifier.padding(8.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(t.coin)
                            Text("Invested: ${t.invested()}")
                            Text("Value: ${t.value()}")
                            Text("PnL: ${t.pnl()} (${t.pnlPercent()}%)")
                        }
                    }
                }
            }
        }
    }
}
